﻿---- Create by Thái Huỳnh Khả Vi on 10/31/2017 4:30:12 PM
---- Lương năng suất theo ngày 

IF NOT EXISTS (SELECT TOP 1 1 FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[HT1119]') AND TYPE IN (N'U'))
BEGIN
CREATE TABLE [dbo].[HT1119]
(
  [APK] UNIQUEIDENTIFIER DEFAULT newid() NOT NULL,
  [DivisionID] VARCHAR(50) NOT NULL,
  [EmployeeID] VARCHAR(50) NOT NULL,
  [MachineID] VARCHAR(50) NOT NULL,
  [TranMonth] INT NOT NULL,
  [TranYear] INT NOT NULL,
  [Type] INT NULL,
  [DepartmentID] VARCHAR(50) NULL, 
  [TeamID] VARCHAR(50) NULL, 
  [Quantity1] DECIMAL(28,8) NULL,
  [Quantity2] DECIMAL(28,8) NULL,
  [Quantity3] DECIMAL(28,8) NULL,
  [Quantity4] DECIMAL(28,8) NULL,
  [Quantity5] DECIMAL(28,8) NULL,
  [Quantity6] DECIMAL(28,8) NULL,
  [Quantity7] DECIMAL(28,8) NULL,
  [Quantity8] DECIMAL(28,8) NULL,
  [Quantity9] DECIMAL(28,8) NULL,
  [Quantity10] DECIMAL(28,8) NULL,
  [Quantity11] DECIMAL(28,8) NULL,
  [Quantity12] DECIMAL(28,8) NULL,
  [Quantity13] DECIMAL(28,8) NULL,
  [Quantity14] DECIMAL(28,8) NULL,
  [Quantity15] DECIMAL(28,8) NULL,
  [Quantity16] DECIMAL(28,8) NULL,
  [Quantity17] DECIMAL(28,8) NULL,
  [Quantity18] DECIMAL(28,8) NULL,
  [Quantity19] DECIMAL(28,8) NULL,
  [Quantity20] DECIMAL(28,8) NULL,
  [Quantity21] DECIMAL(28,8) NULL,
  [Quantity22] DECIMAL(28,8) NULL,
  [Quantity23] DECIMAL(28,8) NULL,
  [Quantity24] DECIMAL(28,8) NULL,
  [Quantity25] DECIMAL(28,8) NULL,
  [Quantity26] DECIMAL(28,8) NULL,
  [Quantity27] DECIMAL(28,8) NULL,
  [Quantity28] DECIMAL(28,8) NULL,
  [Quantity29] DECIMAL(28,8) NULL,
  [Quantity30] DECIMAL(28,8) NULL,
  [Quantity31] DECIMAL(28,8) NULL,
  [CreateUserID] VARCHAR(50) NULL,
  [CreateDate] DATETIME NULL
CONSTRAINT [PK_HT1119] PRIMARY KEY CLUSTERED
(
  [APK],
  [DivisionID]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
ON [PRIMARY]
END